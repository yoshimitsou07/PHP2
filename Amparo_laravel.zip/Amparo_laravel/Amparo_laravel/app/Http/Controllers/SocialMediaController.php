<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SocialMediaController extends Controller
{
    public function social_media(){
    	return view('/socialmedia');
    }
}
