<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AboutPhpController extends Controller
{
    public function aboutphp(){
    	return view ('/aboutphp');
    }
}
