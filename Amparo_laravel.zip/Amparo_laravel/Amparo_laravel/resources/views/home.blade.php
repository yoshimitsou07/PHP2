@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><center>About Me</center></div>

                <div class="panel-body">
                <center>
                  <img src="{{ asset('img/amparo.jpg')}}" style="width: 150px; height: 150px; border-radius:50%; ">
                  </center>
                  <br>
                  
                  <p style=" margin-left: 140px;">
                    Hello and welcome to my site, my name is Ebenezer. I was born in <br>
                    December 18, 1996. I was born in Philippines at Cebu Province. <br>
                    I live in Cebu City. I live with my mother and father. My father <br>
                    has no job so my mother works every day for a living. While my <br>
                    father is at home doing house chores. I have a yunger sister. She <br>
                    is currently a senior high school in University of Cebu. I'm also <br>
                    a student of the college of computer studies in University of Cebu. <br>
                    I reciently both a motor cycle and named her Casper. My hobby is <br>
                    riding motor cylce with friends. I play video games. My religion <br>
                    is Baptist. The name of our church is Chief CornerStone Bilievers <br>
                    Baptist Church. I have two dogs named Max and Sue. They both <br>
                    energetic and sweet. My goal in life is to graduate from collage <br>
                    and be able to help my parents. My father was diagnos of <br>
                    gallstone and kidney stone last June. Throughout the semester <br>
                    I wasn't able to attend to my class because I had to accompany him. <br>
                    His condition got worst and needed a surgery this month please pray <br>
                    for him.
                  </p>
                  </center>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
