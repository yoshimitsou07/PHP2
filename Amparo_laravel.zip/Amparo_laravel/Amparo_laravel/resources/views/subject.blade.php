@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><center>My Subject</center></div>

                 <div class="panel-body">

                 <center>
                 <img src="{{ asset('img/uc.jpg')}}" style="width: 100px;">
                 <h4> <strong>Ebenezer B. Amparo</strong> </h4>
                 </center>      
  <table class="table">
    <thead>
      <tr>
        <th>Schedule No.</th>
        <th>Course No.</th>
        <th>Time</th>
        <th>Days</th>
        <th>Room</th>
        <th>Unit</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>IT-01941</td>
        <td>POL SC 6</td>
        <td>4:30-5:30 PM</td>
        <td>MWF</td>
        <td>614</td>
        <td>3.0</td>
      </tr>
    </tbody>
    <tbody>
      <tr>
        <td>IT-12955</td>
        <td>SOC SC 1D</td>
        <td>5:31-6:31 PM</td>
        <td>MWF</td>
        <td>615</td>
        <td>3.0</td>
      </tr>
    </tbody>
    <tbody>
      <tr>
        <td>IT-02600</td>
        <td>ITELECPHP2  LAB</td>
        <td>7:31-8:31 PM</td>
        <td>MWF</td>
        <td>544</td>
        <td></td>
      </tr>
    </tbody>
    <tbody>
      <tr>
        <td>&nbsp;&nbsp;&nbsp;-</td>
        <td>ITELECPHP2</td>
        <td>6:31-7:31 PM</td>
        <td>MW</td>
        <td>530A</td>
        <td>3.0</td>
      </tr>
    </tbody>
    <tbody>
      <tr>
        <td>IT-01438</td>
        <td>MGT 1A</td>
        <td>9:00-10:30 AM</td>
        <td>TTH</td>
        <td>530B</td>
        <td>3.0</td>
      </tr>
    </tbody>
    <tbody>
      <tr>
        <td>IT-01867</td>
        <td>FREEELCIS</td>
        <td>10:30-12:00 PM</td>
        <td>TTH</td>
        <td>536</td>
        <td>3.0</td>
      </tr>
    </tbody>
    <tbody>
      <tr>
        <td>IT-01362</td>
        <td>AIS32       LAB</td>
        <td>6:31-8:01 PM</td>
        <td>TTH</td>
        <td>542</td>
        <td></td>
      </tr>
    </tbody>
    <tbody>
      <tr>
        <td>&nbsp;&nbsp;&nbsp;-</td>
        <td>AIS32</td>
        <td>5:31-6:31 PM</td>
        <td>TTH</td>
        <td>530A</td>
        <td>3.0</td>
      </tr>
    </tbody>

  </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
