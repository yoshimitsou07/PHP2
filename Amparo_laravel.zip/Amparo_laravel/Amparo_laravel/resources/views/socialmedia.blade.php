@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><center>Social Media Account</center></div>

                <div class="panel-body">
                  <center>
                  <img src="{{ asset('img/amparo.jpg')}}" style="width: 100px; height:100px;border-radius: 50%;">
                 <h4><strong>Ebenezer B. Amparo</strong></h4>

           	<br>
                  <a href="https://www.facebook.com/ebenezer.amparo"><i class="fa fa-facebook"></i>  </a>
&nbsp;&nbsp;&nbsp;
                  <a href="https://twitter.com/EbenezerAmparo"><i class="fa fa-twitter"></i>  </a>
                  &nbsp;&nbsp;&nbsp;
                  <a href="https://github.com/yoshimitsou07"><i class="fa fa-github"></i>  </a>
                  </center>
                  </div>
            </div>
        </div>
    </div>
</div>
@endsection
