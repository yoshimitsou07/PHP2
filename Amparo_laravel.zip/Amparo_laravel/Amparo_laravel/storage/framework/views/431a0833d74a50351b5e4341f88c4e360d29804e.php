<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><center>Education Background</center></div>
                <div class="panel-body">
                <center>
           <img src="<?php echo e(asset('img/amparo.jpg')); ?>" style="width: 100px; height:100px;border-radius: 50%;">
                 <h4><strong>Ebenezer B. Amparo</strong></h4>
                 </center>
    <table class="table">
    <thead>
      <tr>
        <th>Level</th>
        <th>Shool Name</th>
        <th>Year</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Elementary</td>
        <td>Ana Baptist Christian Academy</td>
        <td>2005 - 2011</td>
      </tr>
    </tbody>
    <tbody>
      <tr>
        <td>High School</td>
        <td>First Baptist Christian School</td>
        <td>2011 - 2014 </td>
      </tr>
    </tbody>
    <tbody>
      <tr>
        <td>Collage</td>
        <td>University of Cebu</td>
        <td>2014 - 2017</td>
      </tr>
    </tbody>
    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>