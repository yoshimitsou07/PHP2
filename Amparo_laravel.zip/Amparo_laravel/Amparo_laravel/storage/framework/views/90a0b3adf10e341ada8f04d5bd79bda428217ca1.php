<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">My Profile</div>
                <div class="panel-body">

                   <img src="/uploads/avatars/<?php echo e($user->avatar); ?>" style="width: 150px; height: 150px; float:left; margin-right:50px; border-radius:50%; ">
                   <h4><?php echo e($user->name); ?></h4>
                   <form enctype="multipart/form-data" action="/profile" method="POST">
                       <label>Update Profile Image </label>
                       <input type="file" name="avatar">
                       <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"><br>
                       <input type="submit" name="btn btn-sm btn-inverse">
                   </form>
                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>